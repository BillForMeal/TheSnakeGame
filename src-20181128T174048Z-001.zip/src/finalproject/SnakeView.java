/* *****************************************
* CSCI205 - Software Engineering and Design
* Fall 2018
*
* Name: NAMES of team members
* Date: Nov 10, 2018
* Time: 2:49:59 PM
*
* Project: csci205FinalProject
* Package: finalproject
* File: SnakeView
* Description:
*
* ****************************************
 */
package finalproject;

/**
 *
 * @author yz010
 */
public class SnakeView {

}
